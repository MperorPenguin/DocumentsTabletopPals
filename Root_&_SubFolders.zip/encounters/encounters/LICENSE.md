# SRD Attribution (CC-BY-4.0)
This work includes material from the System Reference Document 5.2 (“SRD 5.2”) by Wizards of the Coast LLC, available at https://www.dndbeyond.com/srd.
The SRD 5.2 is licensed under the Creative Commons Attribution 4.0 International License, available at https://creativecommons.org/licenses/by/4.0/legalcode.
All other code and UI © DocumentsTabletopPals, MIT unless otherwise stated.
